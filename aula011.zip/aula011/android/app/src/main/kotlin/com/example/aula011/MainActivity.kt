package com.example.aula011

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
