import 'package:flutter/material.dart';

class Frase {
  String frase;
  String urlImagem;

  Frase({required this.frase, required this.urlImagem});
}
