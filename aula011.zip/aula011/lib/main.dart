import 'package:aula011/frasesMassa.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: "Frases show de bola",
    debugShowCheckedModeBanner: false,
    home: Frases(),
  ));
}
